class ImageRepository {
  Future<List<Map<String, String>>> fetchImages() async {
    final List<Map<String, String>> images = [];
    for (int i = 0; i < 10; i++) {
      final url = 'https://picsum.photos/id/${i + 10}/500/300';
      images.add({
        "title": "Image ${i + 1}",
        "description": "Random image from picsum",
        "url": url,
      });
    }
    return images;
  }
}
