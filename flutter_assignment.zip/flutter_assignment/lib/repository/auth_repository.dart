class AuthRepository {
  Future<bool> login(String email, String password) async {
    // Accept any credentials that pass validation
    await Future.delayed(Duration(seconds: 1));
    return true;
  }
}
