import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'login_bloc.dart';
import 'login_event.dart';
import 'login_state.dart';
import '../home/home_screen.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state.isSuccess) {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (_) => HomeScreen()));
        } else if (state.isFailure) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Invalid credentials')),
          );
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text("Login")),
        body: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              BlocBuilder<LoginBloc, LoginState>(
                builder: (context, state) {
                  return TextField(
                    onChanged: (val) =>
                        context.read<LoginBloc>().add(EmailChanged(val)),
                    decoration: InputDecoration(
                      labelText: "Email",
                      errorText: state.isValidEmail ? null : "Invalid Email",
                    ),
                  );
                },
              ),
              BlocBuilder<LoginBloc, LoginState>(
                builder: (context, state) {
                  return TextField(
                    obscureText: true,
                    onChanged: (val) =>
                        context.read<LoginBloc>().add(PasswordChanged(val)),
                    decoration: InputDecoration(
                      labelText: "Password",
                      errorText:
                          state.isValidPassword ? null : "Invalid Password",
                    ),
                  );
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () =>
                    context.read<LoginBloc>().add(LoginSubmitted()),
                child: Text("Login"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
