import 'package:flutter_bloc/flutter_bloc.dart';
import 'login_event.dart';
import 'login_state.dart';
import '../repository/auth_repository.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final AuthRepository authRepository;

  LoginBloc(this.authRepository) : super(LoginState.initial()) {
    on<EmailChanged>((event, emit) {
      emit(state.copyWith(
        email: event.email,
        isValidEmail: _validateEmail(event.email),
      ));
    });

    on<PasswordChanged>((event, emit) {
      emit(state.copyWith(
        password: event.password,
        isValidPassword: _validatePassword(event.password),
      ));
    });

    on<LoginSubmitted>((event, emit) async {
      if (!state.isValidEmail || !state.isValidPassword) return;
      emit(state.copyWith(isSubmitting: true));

      final success = await authRepository.login(state.email, state.password);

      emit(state.copyWith(
        isSubmitting: false,
        isSuccess: success,
        isFailure: !success,
      ));
    });
  }

  bool _validateEmail(String email) {
    final regex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
    return regex.hasMatch(email);
  }

  bool _validatePassword(String password) {
    final regex = RegExp(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*\W).{8,}$');
    return regex.hasMatch(password);
  }
}
