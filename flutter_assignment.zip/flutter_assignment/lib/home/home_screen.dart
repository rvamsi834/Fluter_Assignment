import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../repository/image_repository.dart';

class HomeScreen extends StatelessWidget {
  final ImageRepository repo = ImageRepository();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home")),
      body: FutureBuilder<List<Map<String, String>>>(
        future: repo.fetchImages(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final images = snapshot.data!;
          return ListView.builder(
            itemCount: images.length,
            itemBuilder: (context, index) {
              final img = images[index];
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(img["url"]!, fit: BoxFit.cover, width: double.infinity),
                    SizedBox(height: 5),
                    Text(
                      img["title"]!,
                      style: GoogleFonts.montserrat(fontWeight: FontWeight.w600),
                    ),
                    Text(
                      img["description"]!,
                      style: GoogleFonts.montserrat(color: Colors.grey),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
